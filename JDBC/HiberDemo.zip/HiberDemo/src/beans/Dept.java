/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package beans;

/**
 *
 * @author Srinivas
 */
public class Dept {

private int deptID,deptOwner;

private String deptName,deptCat;

    /**
     * @return the deptID
     */
    public int getDeptID() {
        return deptID;
    }

    /**
     * @param deptID the deptID to set
     */
    public void setDeptID(int deptId) {
        this.deptID = deptId;
    }

    /**
     * @return the deptOwner
     */
    public int getDeptOwner() {
        return deptOwner;
    }

    /**
     * @param deptOwner the deptOwner to set
     */
    public void setDeptOwner(int deptOwner) {
        this.deptOwner = deptOwner;
    }

    /**
     * @return the deptName
     */
    public String getDeptName() {
        return deptName;
    }

    /**
     * @param deptName the deptName to set
     */
    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    /**
     * @return the deptCat
     */
    public String getDeptCat() {
        return deptCat;
    }

    /**
     * @param deptCat the deptCat to set
     */
    public void setDeptCat(String deptCat) {
        this.deptCat = deptCat;
    }



}
