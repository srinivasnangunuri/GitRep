
import DAO.EmployeeDao;
import beans.EmployeeRec;
import java.util.List;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Srinivas
 */
public class Worker {

private EmployeeRec employeeRec;
private List<EmployeeRec> employeeRecords = null;

private EmployeeDao employeeDao;

public Worker(){
    employeeDao = new EmployeeDao();


}
//Fetching EmplyeeRec
public void printAllEmployees(){
       employeeRecords = employeeDao.findAll();
       for(EmployeeRec employee:employeeRecords ){
           System.out.println("Employee ID:"+employee.getEmployeeID()+" Name:"+employee.getfName()+" "+employee.getLastName()+" Age:"+employee.getAge()+" Title:"+employee.getTitle()+"\n");
       }
}

//Insert a new Employee Record

//Update an Employee Record

//Fetch a perticular Employee Record

public static void main(String[] args){
    Worker worker = new Worker();
    worker.printAllEmployees();
}

}
