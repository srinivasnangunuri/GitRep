package DAO;

import java.sql.Connection;
import java.sql.SQLException;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.Session;

public class HibernateUtil {

    private static SessionFactory sessionFactory = null;
    private static Connection connection = null;

    public static Session getSession() {
        if(sessionFactory != null){
       return sessionFactory.openSession();
        }
 else{
     sessionFactory = new Configuration().configure().buildSessionFactory(); 
     return sessionFactory.openSession();     
 }


    }

    public static void closeSessionFactory() {
        sessionFactory.close();
    }

    public static void createSQLConnection() {

        try {

            connection = sessionFactory.getCurrentSession().connection();
        } catch (Exception E) {
            E.printStackTrace();
        }
    }

    public static Connection getSQLConnection() {

        return connection;

    }

    public static void closeSQLConnection(){
        try {
            connection.close();
        } catch (SQLException sQLException) {
            System.out.println("Exception in close-"+sQLException);
        }
    }
}
