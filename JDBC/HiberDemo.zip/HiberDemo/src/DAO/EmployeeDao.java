/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package DAO;

import beans.EmployeeRec;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Srinivas
 */
public class EmployeeDao {

public EmployeeDao(){

}

public boolean insert(EmployeeRec employeeRec) {
Session session = HibernateUtil.getSession();
        Transaction tx = null;
        
        try {
            tx = session.beginTransaction();
            session.save(employeeRec);
            tx.commit();
            return true;
        }
        catch (RuntimeException e) {
            System.out.println("Error in add user Details-"+e);
            if(tx != null)
                tx.rollback();
            return false;
          }
        catch(Exception e){
            if(tx != null)
                tx.rollback();
          System.out.println("Error in add user Details-"+e);
          return false;
        }
        finally {
            session.close();
        }

}

public boolean update(int employeeId, EmployeeRec employeeRec){
Session session = HibernateUtil.getSession();
        Transaction tx = null;
        //Update only title and age
        try {
            tx = session.beginTransaction();
            org.hibernate.Query query = session.createQuery("UPDATE EmployeeRec SET title = :Title, age=:Age");
            query.setString("Title", employeeRec.getTitle());
            query.setInteger("Age", employeeRec.getAge());
            query.executeUpdate();
            tx.commit();
            return true;
        }
        catch (RuntimeException e) {
            if(tx != null)
                tx.rollback();
            System.out.println("Error in edit user Details-"+e);
            return false;
          }
        catch(Exception e){
            if(tx != null)
                tx.rollback();
          System.out.println("Error in edit user Details-"+e);
          return false;
        }
        finally {
            session.close();
        }

}

  public List<EmployeeRec> findAll(){
  Session session = HibernateUtil.getSession();
        org.hibernate.Query query = null;
        try {
            session.beginTransaction();
            query = session.createQuery("FROM EmployeeRec");
            } catch(Exception E){
            E.printStackTrace();
        }
    return (List<EmployeeRec>)query.list();
 }

public EmployeeRec findByPrimaryKey(int employeeId){

        Session session = HibernateUtil.getSession();
        EmployeeRec employee = null;

        try {
            session.beginTransaction();
            org.hibernate.Query query = session.createQuery("FROM EmployeeRec WHERE employeeID = :EmployeeID");
            query.setInteger("EmployeeID", employeeId);
            employee = (EmployeeRec) query.uniqueResult();
            } catch(Exception E){
            E.printStackTrace();
        }finally{
            session.close();
        }
         return employee;
  
}


}
