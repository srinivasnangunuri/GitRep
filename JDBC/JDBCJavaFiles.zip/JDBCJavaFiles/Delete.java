import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;


public class Delete {

	public Delete() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		// Register JDBC driver
	     try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     
	     java.sql.PreparedStatement stmt=null;
	     
	   //Open a connection
	     Connection con;
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/firstdb","root","lakers");
		
			Scanner scan = new Scanner(System.in);
			System.out.print("Enter Employee ID to be deleted: ");
			int emp_id = scan.nextInt();
			scan.close();
	     //Execute a query
	     String sql1="delete from employee_rec where Employee_ID = ?";
	     //String sql=sql1+emp_id+";";
	     
	     stmt=con.prepareStatement(sql1);

	     
	   //Bind values into the parameter.
	     stmt.setInt(1, emp_id); 

	     int no=stmt.executeUpdate(); 
	     System.out.println("Number of rows impacted: "+no);
	     
	     stmt.close();
	     con.close();  
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
