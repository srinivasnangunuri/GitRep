import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Inserts {

	public Inserts() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Register JDBC driver
	     try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     
	     java.sql.PreparedStatement stmt=null;
	     
	   //Open a connection
	     Connection con;
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/firstdb","root","lakers");
		
			//Execute a query
	     
	     String query="insert into firstdb.employee_rec values ('1304', 'Steven', 'Palmer','SE',Null,32);";
	     stmt=con.prepareStatement(query);
	     int no=stmt.executeUpdate(query); 
	     System.out.println("Number of rows impacted: "+no);
	     //con.commit();
	     stmt.close();
	     con.close();  
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
