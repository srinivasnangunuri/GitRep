import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class CallableStatement {

	public CallableStatement() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Register JDBC driver
	     try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     
	     java.sql.CallableStatement cstmt=null;
	     
	   //Open a connection
	     Connection con;
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/firstdb","root","lakers");
		
			//Execute a query
	     
	     String SQL="call getEmpName(?,?);";
	     cstmt=con.prepareCall(SQL);
	     
	   //Bind IN parameter first, then bind OUT parameter
	      int empID = 1300;
	      cstmt.setInt(1, empID); // This would set ID as 1300
	      // Because second parameter is OUT so register it
	      cstmt.registerOutParameter(2, java.sql.Types.VARCHAR);
	     
	     cstmt.execute();
	     
	     String Emp_First = cstmt.getString(2);
	     System.out.println("First Name : "+Emp_First);
	     cstmt.close();
	     con.close();  
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
