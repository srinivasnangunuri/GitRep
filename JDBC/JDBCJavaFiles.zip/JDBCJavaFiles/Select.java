import java.sql.*;

public class Select {

	public Select() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	     try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     Connection con;
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/firstdb","root","lakers");
		
	     Statement stmt=con.createStatement();
	     String query="SELECT * FROM employee_rec";
	     ResultSet rs=stmt.executeQuery(query);
	     while(rs.next())
	     {
	          System.out.println(rs.getString("fname"));
	     }    
	     rs.close();
	     stmt.close();
	     con.close();  
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
