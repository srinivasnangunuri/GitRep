import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Transaction {

	public Transaction() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		// Register JDBC driver
	     
		Connection con=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     
	     java.sql.PreparedStatement stmt=null;
	     
	   
		try {
			
			//Open a connection
		     //Connection con;
			
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/firstdb","root","lakers");
		
			con.setAutoCommit(false);
			
		//Execute a query
	     String query1="insert into firstdb.employee_rec values ('1304', 'Steven', 'Palmer','SE',Null,32);";
	     stmt=con.prepareStatement(query1);
	     stmt.executeUpdate(query1); 
	     
	   //Submit a malformed SQL statement that breaks
	   String query2="insert into firstdb.employee_rec values ('1304', 'Ryan','Anderson','SE',Null,35);";
	     stmt=con.prepareStatement(query2);
	     stmt.executeUpdate(query2); 
	     
	     // If there is no error.
	     con.commit();
	     
	     stmt.close();
	     con.close();  
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			   // If there is any error.
			   con.rollback();
			
			e.printStackTrace();
		}
	}

}
