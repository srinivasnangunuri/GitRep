import java.sql.*;


public class PreparedStatement {

	public PreparedStatement() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {

		// Register JDBC driver
	     try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     
	     java.sql.PreparedStatement stmt=null;
	     
	   //Open a connection
	     Connection con;
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/firstdb","root","lakers");
		
			//Execute a query
	     
	     String query="update employee_rec set age='26' where Employee_ID='1300';";
	     stmt=con.prepareStatement(query);
	     int no=stmt.executeUpdate(query); 
	     System.out.println("Number of rows impacted: "+no);
	     con.commit();
	     stmt.close();
	     con.close();  
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
