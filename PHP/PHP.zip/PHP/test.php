<html>
	<head>
		<title>Test Test Test Test Test Test</title>
	</head>
	<body>
		<?php 
		echo "harsha nagulapalli";
		echo "<br/>";
		print "this is next line";
		?>
	</body>
</html>
