<html>
	<head>
		<title> Escaping from HTML</title>
	</head>
	<body>
	<?php
	$expression = true;
	?>
		<?php
			if($expression == true):
		?>
		This will show if the expression is true
		<?php 
			else: 
		?>
		Otherwise this will show.
		<?php 
			endif;
		?>
	</body>
</html>