<html>
	<head>
		<title> Types Check</title>
	</head>
	<body>
		<?php
			$foo  = 10; //integer
			$bar = (boolean) $foo;
			
			echo $foo;
			echo "<br/>";
			echo $bar;
			echo "<br />";
			
			$foo2 = "5bar";
			settype($foo2, "integer"); //$foo2 is now 5
			echo " $foo2  <br/>";
			echo " $foo  <br/>";
		?>
	</body>
</html>