<html>
	<head>
		<title> Escaping from HTML</title>
	</head>
	<body>
		<?php
			echo 'This is a test';
		?>

		<?php echo 'This is a test' ?>	
		<!--below code will not work-->
		<?php echo 'We omitted the last closing tag';?>
	</body>
</html>