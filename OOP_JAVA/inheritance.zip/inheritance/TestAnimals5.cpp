#include <iostream>
#include <string>
 
using namespace std;

// Inheritance Example: Even More Inheritance
 
class AnimalActions
{
public:
	virtual string getName() = 0;
    virtual string talk() = 0;
};

class Animal
{
public:
	Animal(const string& name) : name(name) {}
	string getName() { 
		return name; 
	}

private:
	const string name;
};
 
class Cat : public Animal, public AnimalActions
{
public:
	Cat(const string& name) : Animal(name) {}
	string talk() { 
		return "Meow!"; 
	}
	string getName() { 
		return Animal::getName(); 
	}  
};
 
class Dog : public Animal, public AnimalActions
{
public:
	Dog(const string& name) : Animal(name) {}
	string talk() { 
		return "Arf! Arf!"; 
	}
	string getName() { 
		return Animal::getName(); 
	} 
};

 
class Human : public AnimalActions
{
public:
	Human(const string& name) : name(name) {}
	string getName() { 
		return name; 
	}
	string talk() {
		return "Hello! I am not an animal."; 
	}

private:
	const string name;
};
 

int main()
{
	// why AnimalActions need to be used here?
	AnimalActions *animals[] =
	{
		new Cat("Missy"),
		new Cat("Mr. Mistoffelees"),
		new Dog("Lassie"),
		new Human("Jey Veerasamy")
	};
	
	for(int i = 0; i < 4; i++)
	{
		cout << animals[i]->getName() << ": " << animals[i]->talk() << endl;
		delete animals[i];
	}

	getchar();

	// prints the following:
	//
	// Missy: Meow!
	// Mr. Mistoffelees: Meow!
	// Lassie: Arf! Arf!
	// Jey Veerasmay: Hello! I am not an animal.

	return 0;
}
