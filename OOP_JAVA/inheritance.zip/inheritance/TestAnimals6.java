// Inheritance Example: Basic version

class Animal
{
    private String name;

    public Animal()
    {
        name = "";
    }
	 	 
    public Animal(String name)
    {
        this.name = name;
    }
	 
    public void setName(String name)
    {
        this.name = name;
    }
 
    public String getName()
    {
        return name;
    }
	 
    String talk() {
	 	return "Huh?";
    }
}
 
class Cat
{
    Animal animal;
	 
    public Cat(String name)
    {
	 	  animal = new Animal(name);
    }
 
    public String getName()
    {
        return animal.getName();
    }
	 
    public String talk()
    {
        return "Meowww!";
    }
}
 
class Dog
{
    Animal animal;
	 
    public Dog(String name)
    {
	 	  animal = new Animal(name);
    }
 
    public String getName()
    {
        return animal.getName();
    }
	 
    public String talk()
    {
        return "Arf! Arf!";
    }
}
 
public class TestAnimals6
{
    public static void main(String[] args)
    {
			
        Object[] animals = 
        {
            new Cat("Missy"),
            new Cat("Mr. Mistoffelees"),
            new Dog("Lassie")
        };
 
        for (Object a : animals)
        {
		  		if (a instanceof Cat)
				{
					Cat x = (Cat) a;
					System.out.println(x.getName() + ": " + x.talk());
				} else if (a instanceof Dog)
				{
					Dog x = (Dog) a;
					System.out.println(x.getName() + ": " + x.talk());
				}

        } 
		  
	     // prints the following:
	     //
	     // Missy: Meowww!
	     // Mr. Mistoffelees: Meowww!
	     // Lassie: Arf! Arf!


    }
}
