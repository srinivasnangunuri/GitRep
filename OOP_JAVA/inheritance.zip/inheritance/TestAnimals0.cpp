#include <iostream>
#include <string>
 
using namespace std;
 
class Animal
{
public:
	Animal(const string& nm) : name(nm) { }

	virtual string talk() { 
		return "Huh?"; 
	}
	string getName() { 
		return name; 
	}

	private:
		const string name;
};
 
class Cat : public Animal
{
public:
	Cat(const string& name) : Animal(name) {}
	string talk() { 
		return "Meow!"; 
	}
};
 
class Dog : public Animal
{
public:
	Dog(const string& name) : Animal(name) {}
	string talk() { 
		return "Arf! Arf!"; 
	}
};
 

int main()
{
	Animal animals[] =
	{
		Cat("Missy"),
		Cat("Mr. Mistoffelees"),
		Dog("Lassie")
	};
	
	for(int i = 0; i < 3; i++)
	{
		cout << animals[i].getName() << ": " << animals[i].talk() << endl;
	}

	//getchar();

	// prints the following:
	//
	// Missy: Huh?
	// Mr. Mistoffelees: Huh?
	// Lassie: Huh?

	return 0;
}
