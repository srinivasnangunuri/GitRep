#include <iostream>
#include <string>
 
using namespace std;
 
class Animal
{
public:
	Animal(string name = "") : name(name) {}
	string talk() { 
		return "Huh?"; 
	}
	string getName() { 
		return name; 
	}

private:
	string name;
};
 
class Cat 
{
public:
	Cat(const string& name) {
		animal = Animal(name);
	}

	string talk() { 
		return "Meow!"; 
	}
private:
	Animal animal;
};
 
class Dog 
{
public:
	Dog(const string& name = "") {
		animal = Animal(name);
	}

	string talk() { return "Arf! Arf!"; }
private:
	Animal animal;
};
 

int main()
{
	Animal *animal = (Animal *) new Cat("fun");

	Cat *x = dynamic_cast<Cat*> (animal);
	Dog *y = dynamic_cast<Dog*> (animal);

	/* Animal* animals[] =
	{
		new Cat("Missy"),
		new Cat("Mr. Mistoffelees"),
		new Dog("Lassie")
	};
	
	for(int i = 0; i < 3; i++)
	{
		cout << animals[i]->getName() << ": " << animals[i]->talk() << endl;
		delete animals[i];
	}

	getchar(); */

	// prints the following:
	//
	// Missy: Meow!
	// Mr. Mistoffelees: Meow!
	// Lassie: Arf! Arf!

	return 0;
}
