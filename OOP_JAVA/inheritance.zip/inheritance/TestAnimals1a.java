package inheritance;

// Inheritance Example: Basic version
abstract class Animal {

    private final String name;

    protected Animal(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    abstract String talk();

    String intro() {
        return "Hi, my name is " + name
                + ". I am a " + animalType()
                + ". I usually say " + talk();
    }

    String animalType() {
        return "Unknown";
    }
}

class Cat extends Animal {

    public Cat(String name) {
        super(name);
    }

    public String talk() {
        return "Meowww!";
    }

    String animalType() {
        return "Cat";
    }
}

class Dog extends Animal {

    public Dog(String name) {
        super(name);
    }

    public String talk() {
        return "Arf! Arf!";
    }

    String animalType() {
        return "Dog";
    }
}

class Chicken extends Animal {

    public Chicken(String name) {
        super(name);
    }

    String animalType() {
        return "Chicken";
    }
	 
	 String talk() {
	 		return "Buck...Buck...";
	 }
}

public class TestAnimals1a {

    public static void main(String[] args) {
        Animal[] animals = {
            new Cat("Missy"),
            new Cat("Mr. Mistoffelees"),
            new Dog("Lassie"),
				new Chicken("Tiny")
        };

        for (Animal a : animals) {
            System.out.println(a.getName() + ": " + a.talk());
        }

        for (Animal a : animals) {
            System.out.println(a.intro());
        }

    }
}
