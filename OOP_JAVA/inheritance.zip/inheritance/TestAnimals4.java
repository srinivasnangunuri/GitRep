// Inheritance Example: Using Interface to do more

interface AnimalActions
{
    String getName();
    String talk();
}
 
abstract class Animal implements AnimalActions
{
    private final String name;
 
    protected Animal(String name)
    {
        this.name = name;
    }
 
    public String getName()
    {
        return name;
    }
}
 
class Cat extends Animal
{
    public Cat(String name)
    {
        super(name);
    }
 
    public String talk()
    {
        return "Meowww!";
    }
}
 
class Dog extends Animal
{
    public Dog(String name)
    {
        super(name);
    }
 
    public String talk()
    {
        return "Arf! Arf!";
    }
}

class Human implements AnimalActions
{
    private final String name;
	 
    public Human(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }
	  
    public String talk()
    {
        return "Hello! I am not an animal.";
    }
}
 
public class TestAnimals4
{

    public static void main(String[] args)
    {
	 	  // Why AnimalActions should be used instead Animal?
        AnimalActions[] animals = 
        {
            new Cat("Missy"),
            new Cat("Mr. Mistoffelees"),
            new Dog("Lassie"),
	    		new Human("Jey Veerasamy")
        };
 
        for (AnimalActions a : animals)
        {
            System.out.println(a.getName() + ": " + a.talk());
        }
		  
		  // prints the following:
	     //
	     // Missy: Meowww!
	     // Mr. Mistoffelees: Meowww!
	     // Lassie: Arf! Arf!
		  // Jey Veerasmay: Hello! I am not an animal.
    }
}

