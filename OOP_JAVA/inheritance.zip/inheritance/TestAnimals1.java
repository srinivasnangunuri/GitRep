// Inheritance Example: Basic version

class Animal
{
    private final String name;
	 
    protected Animal(String name)
    {
        this.name = name;
    }
 
    public String getName()
    {
        return name;
    }
	 
    String talk() {
	 	return "Huh?";
    }
}
 
class Cat extends Animal
{
    public Cat(String name)
    {
        super(name);
    }
 
    public String talk()
    {
        return "Meowww!";
    }
}
 
class Dog extends Animal
{
    public Dog(String name)
    {
        super(name);
    }
 
    public String talk()
    {
        return "Arf! Arf!";
    }
}

class BigDog extends Dog
{
    public BigDog(String name)
    {
        super(name);
    }
 
}
 
public class TestAnimals1
{
    public static void main(String[] args)
    {
        Animal[] animals = 
        {
            new Cat("Missy"),
            new Cat("Mr. Mistoffelees"),
            new Dog("Lassie"),
				new BigDog("Mr. X")
        };
 
        for (Animal a : animals)
        {
            System.out.println(a.getName() + ": " + a.talk());
        }
		  
	     // prints the following:
	     //
	     // Missy: Meowww!
	     // Mr. Mistoffelees: Meowww!
	     // Lassie: Arf! Arf!


    }
}
