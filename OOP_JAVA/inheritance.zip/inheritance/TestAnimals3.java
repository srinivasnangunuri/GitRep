// Inheritance Example: Interface

interface AnimalActions
{
    String getName();
    String talk();
}
 
abstract class Animal implements AnimalActions
{
    private final String name;
 
    protected Animal(String name)
    {
        this.name = name;
    }
 
    public String getName()
    {
        return name;
    }
}
 
class Cat extends Animal
{
    public Cat(String name)
    {
        super(name);
    }
 
    public String talk()
    {
        return "Meowww!";
    }
}
 
class Dog extends Animal
{
    public Dog(String name)
    {
        super(name);
    }
 
    public String talk()
    {
        return "Arf! Arf!";
    }
}
 
public class TestAnimals3
{
    public static void main(String[] args)
    {
        Animal[] animals = 
        {
            new Cat("Missy"),
            new Cat("Mr. Mistoffelees"),
            new Dog("Lassie")
        };
 
        for (Animal a : animals)
        {
            System.out.println(a.getName() + ": " + a.talk());
        }
		  
	     // prints the following:
	     //
	     // Missy: Meowww!
	     // Mr. Mistoffelees: Meowww!
	     // Lassie: Arf! Arf!
    }
}
