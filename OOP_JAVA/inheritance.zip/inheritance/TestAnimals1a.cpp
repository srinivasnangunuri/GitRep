#include <iostream>
#include <string>
 
using namespace std;
 
class Animal
{
public:
	Animal(const string& name) : name(name) {}
	virtual string talk() { 
		return "Huh?"; 
	}
	string getName() { 
		return name; 
	}

	virtual string animalType() {
		return "Unknown";
	}

	string intro() {
        return "Hi, my name is " + name
                + ". I am a " + animalType()
                + ". I usually say " + talk();
    }

private:
	const string name;
};
 
class Cat : public Animal
{
public:
	Cat(const string& name) : Animal(name) {}
	string talk() { 
		return "Meow!"; 
	}
	string animalType() {
		return "Cat";
	}
};
 
class Dog : public Animal
{
public:
	Dog(const string& name) : Animal(name) {}
	string talk() { 
		return "Arf! Arf!"; 
	}
	string animalType() {
		return "Dog";
	}
};
 

int main()
{
	Animal* animals[] =
	{
		new Cat("Missy"),
		new Cat("Mr. Mistoffelees"),
		new Dog("Lassie")
	};
	
	for(int i = 0; i < 3; i++)
	{
		cout << animals[i]->getName() << ": " << animals[i]->talk() << endl;
	}

	for(int i = 0; i < 3; i++)
	{
		cout << animals[i]->intro() << endl;
		delete animals[i];
	}

	getchar();

	// prints the following:
	//
	// Missy: Meow!
	// Mr. Mistoffelees: Meow!
	// Lassie: Arf! Arf!

	return 0;
}
